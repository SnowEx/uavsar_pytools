# __init__.py

# Version of the realpython-reader package
__version__ = "0.3.2"