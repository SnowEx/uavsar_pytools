# __init__.py

# Version of the package
__version__ = "0.3.5"